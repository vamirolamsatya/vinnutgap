# Docker
Various Docker-related content such as shellscripts, Dockerfiles and the like. Not necessarily up-to-date or even working. Use at your own risk, apply some common sense.

As of now, only the `ccminer-verus`, `hellminer-verus` and `nheqminer-verus-{binary,source}` Dockerfiles are maintained. See the `unmaintained/` directory for the others. **Note that `README.md` files there within may contain outdated information.**

There's no additional 'dev fee' from using the results of my Docker files. If some of the stuff in this repository did help you out, consider donating some `VRSC` or `KMD` to ` RJgMwyavimFjJ6DtgdkuxxUqWCuKbpf8rp`.
