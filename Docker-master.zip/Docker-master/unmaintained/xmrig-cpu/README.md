# xmrig-cpu Dockerfile

[XMRIG Github Repository](https://github.com/xmrig/xmrig)

This also works on a RaspberryPi 3 or an Asus Tinkerboard. In fact, thats what it was made for.

## Prerequisites

Docker, ~1GB of disk space, Dockerfile.


## Building the Docker image

Easiest way to get up and running:

```
git clone https://github.com/BloodyNora/Docker
cd Docker/xmrig-cpu
./build.sh
<edit run.sh to suit your needs>
./run.sh
```

## Donate

It's easy! Just *don't* change the `run.sh` file and use it as it is to start the miner. This will make it run at my benefit.
