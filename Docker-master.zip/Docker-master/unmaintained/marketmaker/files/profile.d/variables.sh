# environment variables
TERM="xterm"
EDITOR="vi"
PAGER="less"
TZ="Europe/Berlin"
export TERM EDITOR PAGER TZ

