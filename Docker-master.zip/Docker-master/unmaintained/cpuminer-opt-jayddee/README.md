# Dockerfile for cpuminer-opt by JayDDee

See https://github.com/JayDDee/cpuminer-opt

## Prerequisites

Docker, ~400MB of disk space, the Dockerfile.


## Building the Docker image

Easiest way to get up and running:

```
git clone https://github.com/BloodyNora/Docker
cd Docker/cpuminer-opt-jayddee
./build.sh
<edit run.sh to suit your needs>
./run.sh
```

