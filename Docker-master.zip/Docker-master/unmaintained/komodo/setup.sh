#!/bin/bash
DOCKER=$(which docker)
${DOCKER} volume create komodo
